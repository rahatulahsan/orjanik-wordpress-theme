<?php
/**
 * Reader Exception
 *
 * @author Janson
 * @create 2017-11-23
 */
namespace Asan\PHPExcel\Exception;

class ReaderException extends \Exception {

}
