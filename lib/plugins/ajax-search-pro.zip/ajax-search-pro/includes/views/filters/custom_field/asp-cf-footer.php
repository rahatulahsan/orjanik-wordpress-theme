<?php if ($filter->display_mode != 'hidden'): ?>
</fieldset>
<?php endif; ?>
